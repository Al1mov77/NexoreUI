import { useEffect, useRef } from 'react';
import type { Beat } from '../content';
import type { FrameSet } from '../lib/frames';
import { lerp, range, setVar, smooth, useSectionProgress } from '../lib/engine';
import { Lines } from './Type';

interface Props {
  id: string;
  frames: FrameSet;
  /** section height in vh; longer = slower scrub */
  height: number;
  beats: Beat[];
  alt: string;
  /** where the crop is anchored when the 16:9 frame is cropped, 0..1 */
  focal?: [number, number];
  /** slow push-in across the scene */
  zoom?: [number, number];
  /** length of the source clip, only used for the timecode readout */
  seconds?: number;
}

const IN_SPAN = 0.07;
const OUT_SPAN = 0.06;

function drawFrame(
  canvas: HTMLCanvasElement,
  set: FrameSet,
  index: number,
  focal: [number, number],
  zoom: number,
): boolean {
  const ctx = canvas.getContext('2d');
  if (!ctx) return true;
  const i0 = Math.floor(index);
  const f = index - i0;
  const i1 = Math.min(set.count - 1, i0 + 1);
  const a = set.get(i0) ?? set.nearest(i0);
  if (!a) return false;
  const b = f > 0.02 ? set.get(i1) : undefined;
  const W = canvas.width;
  const H = canvas.height;
  const scale = Math.max(W / a.width, H / a.height) * zoom;
  const dw = a.width * scale;
  const dh = a.height * scale;
  const dx = (W - dw) * focal[0];
  const dy = (H - dh) * focal[1];
  ctx.globalAlpha = 1;
  ctx.drawImage(a, dx, dy, dw, dh);
  // Blend neighbouring frames: reads as motion blur and hides the 12 fps step.
  if (b) {
    ctx.globalAlpha = f;
    ctx.drawImage(b, dx, dy, dw, dh);
    ctx.globalAlpha = 1;
  }
  return set.get(i0) !== undefined && (f <= 0.02 || b !== undefined);
}

const stamp = (t: number) => {
  const s = Math.max(0, t);
  const m = Math.floor(s / 60);
  return `${String(m).padStart(2, '0')}:${(s - m * 60).toFixed(1).padStart(4, '0')}`;
};

export function FrameScene({
  id,
  frames,
  height,
  beats,
  alt,
  focal = [0.5, 0.5],
  zoom = [1, 1.08],
  seconds = 10,
}: Props) {
  const sec = useRef<HTMLElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const beatEls = useRef<(HTMLDivElement | null)[]>([]);
  const clock = useRef<HTMLSpanElement>(null);
  const bar = useRef<HTMLSpanElement>(null);
  const lastKey = useRef('');

  // Canvas backing store follows its CSS size (capped, to protect phones).
  useEffect(() => {
    const c = canvas.current;
    if (!c) return;
    const fit = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      const w = Math.min(1600, Math.round(c.clientWidth * dpr));
      c.width = w;
      c.height = Math.max(1, Math.round((w * c.clientHeight) / Math.max(1, c.clientWidth)));
      lastKey.current = '';
    };
    fit();
    const ro = new ResizeObserver(fit);
    ro.observe(c);
    return () => ro.disconnect();
  }, []);

  useSectionProgress(sec, ({ p, visible, near }) => {
    const index = p * (frames.count - 1);
    if (near) frames.window(index, 12);
    else frames.release();
    if (!visible) return;

    const c = canvas.current;
    if (c) {
      const z = lerp(zoom[0], zoom[1], p);
      const key = `${Math.round(index * 200)}|${z.toFixed(3)}|${c.width}`;
      if (key !== lastKey.current && drawFrame(c, frames, index, focal, z)) lastKey.current = key;
    }

    beats.forEach((b, i) => {
      const el = beatEls.current[i];
      if (!el) return;
      const inV = smooth(range(p, b.from, b.from + IN_SPAN));
      const outV = smooth(range(p, b.to - OUT_SPAN, b.to));
      setVar(el, '--in', inV);
      setVar(el, '--out', outV);
      el.style.visibility = inV > 0 && outV < 1 ? 'visible' : 'hidden';
    });

    if (clock.current) clock.current.textContent = stamp(p * seconds);
    if (bar.current) bar.current.style.transform = `scaleX(${p.toFixed(4)})`;
  });

  return (
    <section ref={sec} id={id} className="scene" style={{ height: `${height}vh` }}>
      <div className="scene__pin">
        <canvas ref={canvas} className="scene__canvas" role="img" aria-label={alt} />
        <div className="scene__vignette" />
        <div className="scene__shade" />
        <div className="scene__beats">
          {beats.map((b, i) => (
            <div
              key={i}
              ref={(el) => {
                beatEls.current[i] = el;
              }}
              className={`beat beat--${b.align}${b.outline ? ' beat--outline' : ''}`}
            >
              {b.kicker && <p className="kicker fade">{b.kicker}</p>}
              {b.lines.length > 0 && (
                <h2 className="display">
                  <Lines lines={b.lines} />
                </h2>
              )}
              {b.body && <p className="body fade">{b.body}</p>}
            </div>
          ))}
        </div>
        <div className="scene__hud" aria-hidden="true">
          <span ref={clock} className="hud__clock">
            00:00.0
          </span>
          <span className="hud__total">/ {stamp(seconds)}</span>
          <span className="hud__line">
            <span ref={bar} />
          </span>
        </div>
      </div>
    </section>
  );
}
