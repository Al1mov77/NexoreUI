/**
 * All words and numbers live here. `*word*` renders in italic.
 * Swap the brand and the copy without touching a component.
 */

export const brand = 'Karmin';
export const tagline = 'Pigment Study 01';

export type BeatAlign = 'left' | 'right' | 'center' | 'giant' | 'top' | 'topright';

export interface Beat {
  from: number; // scene progress 0..1 where the beat starts to appear
  to: number; // scene progress where it has fully left
  align: BeatAlign;
  kicker?: string;
  lines: string[];
  body?: string;
  outline?: boolean; // giant outlined type
}

export const chapters = [
  { id: 'overture', label: 'Overture' },
  { id: 'iris', label: 'I — Iris' },
  { id: 'smoke', label: 'II — Smoke' },
  { id: 'black', label: 'III — Black' },
  { id: 'pigment', label: 'IV — Pigment' },
  { id: 'stripes', label: 'V — Stripes' },
  { id: 'plates', label: 'VI — Plates' },
  { id: 'index', label: 'VII — Index' },
] as const;

export const hero = {
  eyebrow: `${brand} — ${tagline}`,
  lines: ['Nothing quiet', 'was ever', 'this *red.*'],
  sub: 'Three films, three stills and one animal changing its mind.',
  cue: 'Scroll',
};

export const irisBeats: Beat[] = [
  { from: 0.04, to: 0.4, align: 'left', kicker: 'I — Iris', lines: ['It sees you', '*first.*'] },
  {
    from: 0.55,
    to: 1.08,
    align: 'right',
    kicker: 'Fact',
    lines: ['The red is', 'an *insect.*'],
    body: 'Carmine is ground from dried cochineal insects. It has dyed cloth, robes and lipstick for five hundred years.',
  },
];

export const smokeBeats: Beat[] = [
  {
    from: 0.03,
    to: 0.3,
    align: 'left',
    kicker: 'II — Smoke',
    lines: ['The room fills', 'before the', 'animal *does.*'],
  },
  {
    from: 0.4,
    to: 0.7,
    align: 'right',
    lines: ['Stay *still.*'],
    body: 'Rose smoke, red rim light. It keeps its distance, then closes it.',
  },
  { from: 0.8, to: 1.08, align: 'center', lines: ['Eye *contact.*'] },
];

export const blackInterlude = {
  kicker: 'III — Black',
  lines: ['Black makes', 'red *louder.*'],
  marquee: ['Carmine', 'Rose Madder', 'Magenta', 'Cochineal', 'Alizarin'],
};

export const morphBeats: Beat[] = [
  { from: 0.02, to: 0.24, align: 'top', kicker: 'IV — Pigment', lines: ['Add *paint.*'] },
  { from: 0.04, to: 0.5, align: 'giant', outline: true, lines: ['Panther'] },
  { from: 0.52, to: 1.08, align: 'giant', outline: true, lines: ['Tiger'] },
  {
    from: 0.66,
    to: 1.08,
    align: 'topright',
    body: 'Same weight, same stare. Only the alarm changed.',
    lines: [],
  },
];

export const stripes = {
  kicker: 'V — Stripes',
  lines: ['No two', '*alike.*'],
  body: 'A tiger’s stripes run through the skin as well as the fur. Every animal carries its own pattern for life.',
};

export interface Plate {
  n: string;
  title: string;
  still: 'halo' | 'panther' | 'tiger';
  /** focus point of the crop, 0..1 of the source still */
  x: number;
  y: number;
  zoom: number;
  hex: string;
  pigment: string;
}

export const plates = {
  kicker: 'VI — Plates',
  lines: ['Five crops,', 'five *reds.*'],
  body: 'Every hex below was sampled from the frames above, not picked from a chart.',
  items: [
    { n: '01', title: 'Iris', still: 'halo', x: 0.7, y: 0.44, zoom: 2.6, hex: '#D5637E', pigment: 'Cochineal' },
    { n: '02', title: 'Muzzle', still: 'panther', x: 0.51, y: 0.7, zoom: 2.0, hex: '#732B3D', pigment: 'Oxblood' },
    { n: '03', title: 'Rim light', still: 'panther', x: 0.3, y: 0.58, zoom: 2.2, hex: '#C51B3A', pigment: 'Carmine' },
    { n: '04', title: 'Stare', still: 'tiger', x: 0.61, y: 0.44, zoom: 2.0, hex: '#A0103A', pigment: 'Crimson Lake' },
    { n: '05', title: 'Brow', still: 'tiger', x: 0.5, y: 0.3, zoom: 1.8, hex: '#E43479', pigment: 'Rose Madder' },
  ] as Plate[],
};

export const swatches = [
  { name: 'Magenta', hex: '#FC318D' },
  { name: 'Rose Madder', hex: '#E43479' },
  { name: 'Alizarin', hex: '#C90C4E' },
  { name: 'Carmine', hex: '#C51B3A' },
  { name: 'Cochineal', hex: '#D5637E' },
];

export const finale = {
  kicker: 'VII — Index',
  lines: ['Pick a *red.*'],
  body: 'Five reds sampled from these films. Tap one.',
  cta: 'Get the swatch book',
  footnote: `${brand} is a concept page. Footage and stills were generated with AI.`,
};
