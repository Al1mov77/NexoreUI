import { useRef } from 'react';
import { assets } from '../assets';
import { blackInterlude } from '../content';
import { lerp, range, setVar, smooth, useSectionProgress } from '../lib/engine';
import { Lines } from './Type';

/** Still #1: an iris of light opens from the eyes while two rows of pigment names slide past. */
export function Interlude() {
  const sec = useRef<HTMLElement>(null);
  const clip = useRef<HTMLDivElement>(null);
  const img = useRef<HTMLImageElement>(null);
  const rowA = useRef<HTMLDivElement>(null);
  const rowB = useRef<HTMLDivElement>(null);
  const beat = useRef<HTMLDivElement>(null);

  useSectionProgress(sec, ({ p, visible }) => {
    if (!visible) return;
    const open = smooth(range(p, 0.02, 0.5));
    if (clip.current) clip.current.style.clipPath = `circle(${(open * 78).toFixed(2)}% at 50% 44%)`;
    if (img.current) img.current.style.transform = `scale(${lerp(1.3, 1, smooth(range(p, 0, 0.8))).toFixed(4)})`;
    const dist = window.innerWidth * 2.2;
    if (rowA.current) rowA.current.style.transform = `translate3d(${(-p * dist).toFixed(1)}px,0,0)`;
    if (rowB.current) rowB.current.style.transform = `translate3d(${(p * dist - dist).toFixed(1)}px,0,0)`;
    if (beat.current) {
      setVar(beat.current, '--in', smooth(range(p, 0.42, 0.55)));
      setVar(beat.current, '--out', 0);
    }
  });

  const words = [...blackInterlude.marquee, ...blackInterlude.marquee, ...blackInterlude.marquee];
  const row = (
    <>
      {words.map((w, i) => (
        <span key={i}>
          {w}
          <b aria-hidden="true">/</b>
        </span>
      ))}
    </>
  );

  return (
    <section ref={sec} id="black" className="interlude">
      <div className="interlude__pin">
        <div ref={clip} className="interlude__clip">
          <img
            ref={img}
            src={assets.panther}
            alt="A black panther with red rim light staring at the camera"
            decoding="async"
          />
          <div className="interlude__shade" />
        </div>
        <div ref={rowA} className="marquee marquee--top" aria-hidden="true">
          {row}
        </div>
        <div ref={rowB} className="marquee marquee--bottom" aria-hidden="true">
          {row}
        </div>
        <div ref={beat} className="beat beat--left beat--low">
          <p className="kicker fade">{blackInterlude.kicker}</p>
          <h2 className="display">
            <Lines lines={blackInterlude.lines} />
          </h2>
        </div>
      </div>
    </section>
  );
}
