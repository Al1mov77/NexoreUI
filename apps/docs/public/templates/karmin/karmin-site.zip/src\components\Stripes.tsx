import { useRef } from 'react';
import { assets } from '../assets';
import { stripes } from '../content';
import { lerp, range, setVar, smooth, useSectionProgress } from '../lib/engine';
import { Lines } from './Type';

/** Still #2: the tiger is revealed through vertical slats that widen with scroll, like blinds made of stripes. */
export function Stripes() {
  const sec = useRef<HTMLElement>(null);
  const stage = useRef<HTMLDivElement>(null);
  const img = useRef<HTMLImageElement>(null);
  const beat = useRef<HTMLDivElement>(null);

  useSectionProgress(sec, ({ p, visible }) => {
    if (!visible) return;
    const open = smooth(range(p, 0.03, 0.6));
    if (stage.current) setVar(stage.current, '--r', open * 1.004);
    if (img.current) img.current.style.transform = `scale(${lerp(1.16, 1, open).toFixed(4)})`;
    if (beat.current) {
      setVar(beat.current, '--in', smooth(range(p, 0.45, 0.62)));
      setVar(beat.current, '--out', 0);
    }
  });

  return (
    <section ref={sec} id="stripes" className="stripes">
      <div className="stripes__pin">
        <div ref={stage} className="stripes__stage">
          <img
            ref={img}
            src={assets.tiger}
            alt="A hot pink tiger with dark crimson stripes staring at the camera"
            decoding="async"
          />
        </div>
        <div className="stripes__shade" />
        <div ref={beat} className="beat beat--left beat--low">
          <p className="kicker fade">{stripes.kicker}</p>
          <h2 className="display">
            <Lines lines={stripes.lines} />
          </h2>
          <p className="body fade">{stripes.body}</p>
        </div>
      </div>
    </section>
  );
}
