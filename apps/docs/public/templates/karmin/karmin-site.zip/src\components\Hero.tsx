import { useEffect, useRef } from 'react';
import { assets } from '../assets';
import { hero } from '../content';
import { clamp, lerp, useTick } from '../lib/engine';
import { Lines } from './Type';

export function Hero() {
  const img = useRef<HTMLImageElement>(null);
  const glow = useRef<HTMLDivElement>(null);
  const copy = useRef<HTMLDivElement>(null);
  const mouse = useRef({ x: 0, y: 0, sx: 0, sy: 0 });

  useEffect(() => {
    const move = (e: PointerEvent) => {
      mouse.current.x = e.clientX / window.innerWidth - 0.5;
      mouse.current.y = e.clientY / window.innerHeight - 0.5;
    };
    window.addEventListener('pointermove', move);
    return () => window.removeEventListener('pointermove', move);
  }, []);

  useTick((s) => {
    const m = mouse.current;
    m.sx = lerp(m.sx, m.x, 0.06);
    m.sy = lerp(m.sy, m.y, 0.06);
    const p = clamp(s.y / Math.max(1, s.vh));
    if (p >= 1) return;
    if (img.current) {
      img.current.style.transform = `translate3d(${(-m.sx * 26).toFixed(2)}px, ${(p * s.vh * 0.2 - m.sy * 16).toFixed(2)}px, 0) scale(${(1.06 + p * 0.14).toFixed(4)})`;
    }
    if (glow.current) {
      glow.current.style.opacity = String(0.55 + p * 0.45);
      glow.current.style.transform = `scale(${(1 + p * 1.4).toFixed(3)})`;
    }
    if (copy.current) {
      copy.current.style.transform = `translate3d(0, ${(-p * s.vh * 0.14).toFixed(2)}px, 0)`;
      copy.current.style.opacity = String(Math.max(0, 1 - p * 1.5));
    }
  });

  return (
    <section id="overture" className="hero">
      <img
        ref={img}
        className="hero__img"
        src={assets.halo}
        alt="A black panther with pink eyes in front of a magenta glow"
        decoding="async"
      />
      <div ref={glow} className="hero__glow" aria-hidden="true" />
      <div className="hero__shade" aria-hidden="true" />
      <div ref={copy} className="hero__copy">
        <p className="kicker rise" style={{ '--i': 0 } as React.CSSProperties}>
          <span className="rise__in">{hero.eyebrow}</span>
        </p>
        <h1 className="display display--hero">
          <Lines lines={hero.lines} mode="rise" />
        </h1>
        <p className="hero__sub fade-in">{hero.sub}</p>
      </div>
      <div className="hero__cue" aria-hidden="true">
        <span>{hero.cue}</span>
        <i />
      </div>
    </section>
  );
}
