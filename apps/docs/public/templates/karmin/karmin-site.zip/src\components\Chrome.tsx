import { useEffect, useRef, useState } from 'react';
import { brand, chapters } from '../content';
import { lerp, useTick } from '../lib/engine';

/** Fixed furniture: brand, current chapter, scroll percentage, hairline progress. */
export function Nav() {
  const [active, setActive] = useState(0);
  const pct = useRef<HTMLSpanElement>(null);
  const line = useRef<HTMLSpanElement>(null);
  const tops = useRef<number[]>([]);
  const n = useRef(0);

  const measure = () => {
    tops.current = chapters.map((c) => {
      const el = document.getElementById(c.id);
      return el ? el.getBoundingClientRect().top + window.scrollY : Infinity;
    });
  };

  useEffect(() => {
    measure();
    window.addEventListener('resize', measure);
    window.addEventListener('load', measure);
    return () => {
      window.removeEventListener('resize', measure);
      window.removeEventListener('load', measure);
    };
  }, []);

  useTick((s) => {
    if (n.current++ % 45 === 0) measure();
    let a = 0;
    tops.current.forEach((t, i) => {
      if (s.y + s.vh * 0.5 >= t) a = i;
    });
    setActive((prev) => (prev === a ? prev : a));
    const p = Math.min(1, Math.max(0, s.y / s.max));
    if (pct.current) pct.current.textContent = String(Math.round(p * 100)).padStart(3, '0');
    if (line.current) line.current.style.transform = `scaleX(${p.toFixed(4)})`;
  });

  return (
    <header className="nav">
      <a className="nav__brand" href="#overture" data-hover>
        {brand}
      </a>
      <p className="nav__chapter" aria-live="polite">
        <span key={active}>{chapters[active].label}</span>
      </p>
      <p className="nav__pct" aria-hidden="true">
        <span ref={pct}>000</span>
        <small>%</small>
      </p>
      <span className="nav__line" aria-hidden="true">
        <span ref={line} />
      </span>
    </header>
  );
}

/** Dot + lagging ring. Only mounted where a real pointer exists. */
export function Cursor() {
  const dot = useRef<HTMLDivElement>(null);
  const ring = useRef<HTMLDivElement>(null);
  const q = useRef({ x: -100, y: -100, rx: -100, ry: -100, hover: false });
  const enabled = typeof matchMedia !== 'undefined' && matchMedia('(hover: hover) and (pointer: fine)').matches;

  useEffect(() => {
    if (!enabled) return;
    document.documentElement.classList.add('has-cursor');
    const move = (e: PointerEvent) => {
      q.current.x = e.clientX;
      q.current.y = e.clientY;
      q.current.hover = !!(e.target as Element | null)?.closest('a, button, [data-hover]');
    };
    window.addEventListener('pointermove', move);
    return () => {
      document.documentElement.classList.remove('has-cursor');
      window.removeEventListener('pointermove', move);
    };
  }, [enabled]);

  useTick(() => {
    const c = q.current;
    c.rx = lerp(c.rx, c.x, 0.16);
    c.ry = lerp(c.ry, c.y, 0.16);
    if (dot.current) dot.current.style.transform = `translate3d(${c.x}px, ${c.y}px, 0)`;
    if (ring.current) {
      ring.current.style.transform = `translate3d(${c.rx}px, ${c.ry}px, 0) scale(${c.hover ? 2.4 : 1})`;
    }
  });

  if (!enabled) return null;
  return (
    <>
      <div ref={ring} className="cursor cursor--ring" aria-hidden="true" />
      <div ref={dot} className="cursor cursor--dot" aria-hidden="true" />
    </>
  );
}

/** Film grain: one noise tile, nudged around in steps by CSS. */
export function Grain() {
  useEffect(() => {
    const c = document.createElement('canvas');
    c.width = c.height = 180;
    const ctx = c.getContext('2d');
    if (!ctx) return;
    const img = ctx.createImageData(180, 180);
    for (let i = 0; i < img.data.length; i += 4) {
      const v = Math.random() * 255;
      img.data[i] = img.data[i + 1] = img.data[i + 2] = v;
      img.data[i + 3] = 255;
    }
    ctx.putImageData(img, 0, 0);
    document.documentElement.style.setProperty('--noise', `url(${c.toDataURL('image/png')})`);
  }, []);
  return <div className="grain" aria-hidden="true" />;
}
