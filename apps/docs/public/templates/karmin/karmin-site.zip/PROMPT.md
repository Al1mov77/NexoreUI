# Agent prompt: scroll-driven landing page from AI clips and stills

You are a senior creative developer. Build a long, cinematic, scroll-driven landing page from the media I attach (3 short AI videos and 3 AI stills). It must feel like a directed film that the scrollbar plays, not a template with a video in the hero.

## Inputs
- 3 clips, about 10 s, 1280x720, 24 fps. Subject centred in frame.
- 3 stills, 16:9.
- Look at every clip and still before you plan anything. Name each scene after what actually happens in it.

## Deliverables
1. `preview.html`: one self-contained file (inlined JS, CSS and a lighter frame set as data URIs) for checking the result by double-click.
2. A React + TypeScript + Vite project (React 18, no animation libraries).
3. A zip with the project, all extracted frames, the stills and the source clips.
4. A short README.

## Pipeline
- Extract frames with ffmpeg: every 2nd frame, 1280 px wide, WebP quality about 72 (about 120 frames per clip). Preview build: every 4th frame, 1024 px, quality about 58.
- Plot the story as alternating clip, still, clip, still. Choose the order so that the last frame of one clip and the first frame of the next match (same pose, same framing) and the cut disappears.
- Sample real colours from the frames (most saturated median of a region) and use those hex values as the palette and as visible content. Do not invent a palette.

## Engineering rules
- Never hijack native scroll. One `requestAnimationFrame` loop reads `scrollY` and eases a second value; all visuals follow the eased value. Layout stays native `position: sticky`.
- Each scene is a tall section with a sticky 100svh child. Progress `p` runs 0..1 across the pinned travel.
- Frame playback on a canvas, cover-fit with a focal point, slight push-in zoom, and blend the two nearest frames by the fractional index so 12 fps reads smooth.
- Memory: keep the compressed frames as Blobs and decode only a window of about ±12 frames into `ImageBitmap`. Close everything outside it. Release a scene when it is more than about 2.5 viewports away.
- Text beats: `{from, to, align, kicker, lines, body}` in a content file. Lines reveal through an overflow mask, driven by CSS custom properties `--in` and `--out` that JS sets from scroll progress. Stagger by a `--i` index in CSS.
- One distinct mechanism per still, never the same effect twice: circular iris reveal with clip-path plus scroll-driven outline marquee; vertical slat reveal via CSS mask-image; horizontal gallery whose section height equals track width, with each crop drifting against the track; a final screen with recolourable swatches (use `@property --accent`) and a magnetic button.
- Furniture: preloader with real progress (waits only for the first clip and hero still, the rest loads quietly), fixed nav with live chapter name and percentage, film-grain tile, custom cursor only for fine pointers, timecode readout on clips.
- Mobile: portrait crop around the focal point, stacked text, plate captions in one column. Respect `prefers-reduced-motion`.

## Art direction
- Dark, high contrast, one hue family. A high-contrast serif (Bodoni Moda) for display with italics for the key word, a wide grotesque (Archivo) for labels. No Inter, no Space Grotesk.
- Giant outlined words may sit over the footage. Keep text out of the subject's face.
- Forbidden: purple-blue gradients, emoji, glassmorphism cards, centered stock hero, three-column feature grids, "revolutionary", "unleash", "elevate", "seamless", "next-level".
- Copy: short, concrete, true. Prefer a real fact (for example where a pigment comes from) to a slogan. Put all copy in one content file. Mark the page as a concept and say the media is AI generated.

## Verification (required before you report)
- Bundle and open `preview.html` in headless Chromium. Fix every console and page error.
- Take screenshots at desktop 1440x810 and mobile 390x844 at about 18 scroll positions covering every scene start, middle and end.
- Look at them. Check overlap of text and subject, clipped text, horizontal overflow (must be 0), blank canvas frames and colour banding.
- Report what you could not verify.
