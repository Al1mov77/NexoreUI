import { useEffect, useRef, type RefObject } from 'react';

/* ------------------------------------------------------------------ math */
export const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const range = (v: number, a: number, b: number) => clamp((v - a) / (b - a));
export const smooth = (t: number) => t * t * (3 - 2 * t);

export const prefersReducedMotion = () =>
  typeof matchMedia !== 'undefined' && matchMedia('(prefers-reduced-motion: reduce)').matches;

/* --------------------------------------------------------- scroll engine */
/**
 * One requestAnimationFrame loop for the whole page.
 * Native scrolling is never hijacked: we read window.scrollY and ease a
 * second value (`y`) towards it. Everything visual follows `y`, so the page
 * feels weighted while sticky layout stays 100% native.
 */
export interface ScrollState {
  y: number; // eased scroll position, px
  target: number; // real scroll position, px
  vh: number;
  vw: number;
  velocity: number; // px / s, eased
  max: number; // max scrollable distance, px
}

export const scroll: ScrollState = { y: 0, target: 0, vh: 0, vw: 0, velocity: 0, max: 1 };

type Tick = (s: ScrollState, dt: number, time: number) => void;
const subs = new Set<Tick>();
let running = false;

function measureViewport() {
  scroll.vh = window.innerHeight;
  scroll.vw = window.innerWidth;
  scroll.max = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
}

function startEngine() {
  if (running) return;
  running = true;
  measureViewport();
  scroll.y = scroll.target = window.scrollY;
  window.addEventListener('resize', measureViewport);
  let last = performance.now();
  let frame = 0;
  const loop = (now: number) => {
    const dt = Math.min(0.05, (now - last) / 1000) || 0.016;
    last = now;
    if (++frame % 30 === 0) measureViewport();
    scroll.target = window.scrollY;
    const k = prefersReducedMotion() ? 1 : 1 - Math.exp(-dt * 8);
    const prev = scroll.y;
    scroll.y += (scroll.target - scroll.y) * k;
    if (Math.abs(scroll.target - scroll.y) < 0.05) scroll.y = scroll.target;
    scroll.velocity = lerp(scroll.velocity, (scroll.y - prev) / dt, 0.2);
    subs.forEach((fn) => fn(scroll, dt, now / 1000));
    requestAnimationFrame(loop);
  };
  requestAnimationFrame(loop);
}

export function subscribe(fn: Tick) {
  subs.add(fn);
  startEngine();
  return () => {
    subs.delete(fn);
  };
}

/** Run `fn` on every engine tick for the lifetime of the component. */
export function useTick(fn: Tick) {
  const ref = useRef(fn);
  ref.current = fn;
  useEffect(() => subscribe((s, dt, t) => ref.current(s, dt, t)), []);
}

/* ------------------------------------------------- section progress hook */
export interface SectionInfo {
  p: number; // 0..1 progress through the pinned travel
  visible: boolean; // any part of the section is on screen
  near: boolean; // within 1.5 viewports, good time to warm up assets
  top: number;
  height: number;
}

/**
 * Reports how far the eased scroll is through a tall section whose child is
 * `position: sticky`. Progress runs from the moment the section reaches the
 * top of the viewport until its last screen is reached.
 */
export function useSectionProgress(
  ref: RefObject<HTMLElement | null>,
  cb: (info: SectionInfo, s: ScrollState) => void,
) {
  const cbRef = useRef(cb);
  cbRef.current = cb;
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let top = 0;
    let height = 0;
    const measure = () => {
      const r = el.getBoundingClientRect();
      top = r.top + window.scrollY;
      height = r.height;
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    window.addEventListener('resize', measure);
    window.addEventListener('load', measure);
    let n = 0;
    let wasVisible = false;
    let wasNear = false;
    const off = subscribe((s) => {
      if (++n % 60 === 0) measure();
      const travel = Math.max(1, height - s.vh);
      const p = clamp((s.y - top) / travel);
      const visible = s.y + s.vh > top && s.y < top + height;
      const near = s.y + s.vh * 2.5 > top && s.y < top + height + s.vh * 1.5;
      if (visible || wasVisible || near || wasNear) {
        cbRef.current({ p, visible, near, top, height }, s);
      }
      wasVisible = visible;
      wasNear = near;
    });
    return () => {
      off();
      ro.disconnect();
      window.removeEventListener('resize', measure);
      window.removeEventListener('load', measure);
    };
  }, [ref]);
}

/** Set a CSS custom property only when its value really changed. */
const written = new WeakMap<HTMLElement, Record<string, string>>();
export function setVar(el: HTMLElement, name: string, value: number, digits = 4) {
  const v = value.toFixed(digits);
  let cache = written.get(el);
  if (!cache) written.set(el, (cache = {}));
  if (cache[name] !== v) {
    cache[name] = v;
    el.style.setProperty(name, v);
  }
}
