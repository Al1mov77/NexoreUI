import { FrameSet } from './lib/frames';

/**
 * Where the media lives. In the Vite project it is plain files under /public.
 * `scripts/build-preview.mjs` injects window.__KARMIN_ASSETS__ with data URIs
 * to produce a single-file preview.html from the very same code.
 */
export interface AssetManifest {
  eye: string[];
  smoke: string[];
  morph: string[];
  halo: string;
  tiger: string;
  panther: string;
}

declare global {
  interface Window {
    __KARMIN_ASSETS__?: AssetManifest;
  }
}

const pad = (n: number) => String(n).padStart(4, '0');
const seq = (dir: string, count: number) =>
  Array.from({ length: count }, (_, i) => `frames/${dir}/${pad(i + 1)}.webp`);

const files: AssetManifest = {
  eye: seq('eye', 120),
  smoke: seq('smoke', 120),
  morph: seq('morph', 120),
  halo: 'stills/halo.webp',
  tiger: 'stills/tiger.webp',
  panther: 'stills/panther.webp',
};

export const assets: AssetManifest = window.__KARMIN_ASSETS__ ?? files;

export const frameSets = {
  eye: new FrameSet(assets.eye),
  smoke: new FrameSet(assets.smoke),
  morph: new FrameSet(assets.morph),
};
