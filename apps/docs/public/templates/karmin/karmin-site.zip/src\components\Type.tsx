import { Fragment, type CSSProperties } from 'react';

/** `*word*` becomes italic. Plain strings stay plain. */
export function Rich({ text }: { text: string }) {
  return (
    <>
      {text
        .split(/(\*[^*]+\*)/g)
        .filter(Boolean)
        .map((part, i) =>
          part.startsWith('*') ? <i key={i}>{part.slice(1, -1)}</i> : <Fragment key={i}>{part}</Fragment>,
        )}
    </>
  );
}

/**
 * One masked line per string. `--i` is the line index; CSS uses it to stagger
 * the reveal, driven either by scroll (`.line`) or by time (`.rise`).
 */
export function Lines({ lines, mode = 'line' }: { lines: string[]; mode?: 'line' | 'rise' }) {
  return (
    <>
      {lines.map((text, i) => (
        <span key={i} className={mode} style={{ '--i': i } as CSSProperties}>
          <span className={`${mode}__in`}>
            <Rich text={text} />
          </span>
        </span>
      ))}
    </>
  );
}
