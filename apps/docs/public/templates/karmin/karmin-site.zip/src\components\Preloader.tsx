import { useRef } from 'react';
import { brand, tagline } from '../content';
import { lerp, useTick } from '../lib/engine';

/** Counts up to the real load progress, then lifts away like a curtain. */
export function Preloader({ progress, done }: { progress: number; done: boolean }) {
  const num = useRef<HTMLSpanElement>(null);
  const shown = useRef(0);

  useTick(() => {
    shown.current = lerp(shown.current, progress, 0.12);
    if (num.current) num.current.textContent = String(Math.min(100, Math.round(shown.current * 100))).padStart(3, '0');
  });

  return (
    <div className={`preload${done ? ' is-done' : ''}`} role="status" aria-live="polite">
      <p className="preload__meta">{tagline}</p>
      <p className="preload__count">
        <span ref={num}>000</span>
        <small>%</small>
      </p>
      <p className="preload__brand">{brand}</p>
      <span className="preload__bar" aria-hidden="true" style={{ transform: `scaleX(${progress.toFixed(3)})` }} />
    </div>
  );
}
