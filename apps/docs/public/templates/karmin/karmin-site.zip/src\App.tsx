import { useEffect, useState } from 'react';
import { assets, frameSets } from './assets';
import { irisBeats, morphBeats, smokeBeats } from './content';
import { Cursor, Grain, Nav } from './components/Chrome';
import { Finale } from './components/Finale';
import { FrameScene } from './components/FrameScene';
import { Hero } from './components/Hero';
import { Interlude } from './components/Interlude';
import { Plates } from './components/Plates';
import { Preloader } from './components/Preloader';
import { Stripes } from './components/Stripes';

/**
 * Story order (clip -> still -> clip -> still):
 *   Overture (still) -> Iris (clip) -> Smoke (clip) -> Black (still)
 *   -> Pigment (clip) -> Stripes (still) -> Plates (crops) -> Index
 * Smoke ends on a close panther face and Pigment starts on one, so the cut is invisible.
 */
export default function App() {
  const [progress, setProgress] = useState(0);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
    window.scrollTo(0, 0);

    const started = performance.now();
    const hero = new Image();
    hero.src = assets.halo;
    let heroDone = false;
    let eyeFraction = 0;
    const report = () => setProgress(Math.min(0.98, eyeFraction * 0.85 + (heroDone ? 0.15 : 0)));

    const heroLoaded = hero.decode().catch(() => undefined).then(() => {
      heroDone = true;
      report();
    });
    const eyeLoaded = frameSets.eye.load((f) => {
      eyeFraction = f;
      report();
    });

    Promise.all([heroLoaded, eyeLoaded]).then(async () => {
      const wait = Math.max(0, 1200 - (performance.now() - started));
      await new Promise((r) => setTimeout(r, wait));
      setProgress(1);
      setReady(true);
      // the remaining scenes download quietly while the visitor reads the hero
      frameSets.smoke.load().then(() => frameSets.morph.load());
    });
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle('is-ready', ready);
    root.classList.toggle('is-loading', !ready);
  }, [ready]);

  return (
    <>
      <Preloader progress={progress} done={ready} />
      <Grain />
      <Cursor />
      <Nav />
      <main>
        <Hero />
        <FrameScene
          id="iris"
          frames={frameSets.eye}
          height={380}
          beats={irisBeats}
          alt="Macro of a pink-red panther eye, the pupil slowly breathing"
          focal={[0.5, 0.5]}
          zoom={[1, 1.12]}
        />
        <FrameScene
          id="smoke"
          frames={frameSets.smoke}
          height={520}
          beats={smokeBeats}
          alt="A black panther walking through rose-coloured smoke"
          focal={[0.5, 0.45]}
          zoom={[1, 1.06]}
        />
        <Interlude />
        <FrameScene
          id="pigment"
          frames={frameSets.morph}
          height={560}
          beats={morphBeats}
          alt="The panther melts into red and pink paint that reforms as a tiger"
          focal={[0.5, 0.4]}
          zoom={[1.02, 1]}
        />
        <Stripes />
        <Plates />
        <Finale />
      </main>
    </>
  );
}
