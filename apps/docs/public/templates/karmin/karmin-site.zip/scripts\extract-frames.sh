#!/usr/bin/env bash
# Rebuilds public/frames and public/stills from the files in source/.
# Needs ffmpeg with libwebp. Usage: npm run frames
set -euo pipefail
cd "$(dirname "$0")/.."

STEP=${STEP:-2}        # keep every Nth source frame (24 fps / 2 = 12 fps, 120 frames for 10 s)
WIDTH=${WIDTH:-1280}   # frame width in px
QUALITY=${QUALITY:-72} # WebP quality

for video in source/videos/*.mp4; do
  name=$(basename "$video" .mp4)
  rm -rf "public/frames/$name" && mkdir -p "public/frames/$name"
  ffmpeg -v error -y -i "$video" \
    -vf "select='not(mod(n,$STEP))',scale=$WIDTH:-2:flags=lanczos" -vsync 0 \
    -c:v libwebp -quality "$QUALITY" -compression_level 5 \
    "public/frames/$name/%04d.webp"
  echo "$name: $(ls public/frames/$name | wc -l) frames"
done

mkdir -p public/stills
for still in source/stills/*.jpg; do
  name=$(basename "$still" .jpg)
  ffmpeg -v error -y -i "$still" -vf "scale='min(2200,iw)':-2:flags=lanczos" -c:v libwebp -quality 82 "public/stills/$name.webp"
  echo "still: $name"
done
echo "Done. If the frame count changed, update the counts in src/assets.ts."
