# Karmin — scroll film (React + TypeScript + Vite)

Three AI clips and three stills turned into one long scroll story.
Clips are played by the scrollbar (frame sequence on canvas), stills get their own scroll-driven effects.

```
npm install
npm run dev            # http://localhost:5173
npm run build          # type-check + production build into dist/
npm run preview:html   # one self-contained preview.html (lighter frames, no server needed)
npm run frames         # re-extract public/frames + public/stills from source/
```

## Story order
Overture (still) → I Iris (clip) → II Smoke (clip) → III Black (still) → IV Pigment (clip) → V Stripes (still) → VI Plates (crops) → VII Index

## Where things live
| Path | What |
|---|---|
| `src/content.ts` | every word, number, hex and beat timing. Change copy here only |
| `src/assets.ts` | frame counts and file paths |
| `src/lib/engine.ts` | one rAF loop, eased scroll, `useSectionProgress` |
| `src/lib/frames.ts` | `FrameSet`: keeps compressed frames, decodes only a window around the playhead |
| `src/components/FrameScene.tsx` | pinned canvas scene + text beats + timecode |
| `src/components/Interlude.tsx` | iris clip-path reveal + pigment marquee |
| `src/components/Stripes.tsx` | blind-style slat reveal (CSS mask) |
| `src/components/Plates.tsx` | horizontal gallery driven by vertical scroll |
| `src/components/Finale.tsx` | recolorable swatches, magnetic button |
| `public/frames/{eye,smoke,morph}/` | 120 WebP frames per clip (1280x720, 12 fps) |
| `source/` | original videos and stills |

## Swapping in new media
1. Put new clips in `source/videos/` (names `eye`, `smoke`, `morph`) and stills in `source/stills/`.
2. `npm run frames`. If the frame count changed, edit the counts in `src/assets.ts`.
3. Adjust `height` (scroll length in vh) and `focal` / `zoom` per scene in `src/App.tsx`.
4. Retime text in `src/content.ts` (`from`/`to` are scene progress 0..1).

## Notes
- Mobile crops the 16:9 clips to portrait around `focal`. Keep the subject centred when generating.
- `prefers-reduced-motion` turns off scroll easing, grain and entrance transitions.
- Fonts: Bodoni Moda + Archivo from Google Fonts (link in `index.html`).
- Brand name, copy and pigment names are placeholders. The hex values were sampled from the actual frames.
