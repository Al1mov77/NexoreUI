// Builds preview.html: ONE self-contained file (code, styles, a lighter set of frames, stills).
// Open it by double-click, drop it in a chat, or host it anywhere. No server, no npm install of the app.
//   npm run preview:html
// Needs: node 18+, esbuild (devDependency), ffmpeg with libwebp.
import { build } from 'esbuild';
import { execFileSync } from 'node:child_process';
import { mkdirSync, mkdtempSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const tmp = mkdtempSync(path.join(tmpdir(), 'karmin-preview-'));

const STEP = Number(process.env.STEP ?? 4); // every 4th source frame = 60 frames per clip
const WIDTH = Number(process.env.WIDTH ?? 1024);
const QUALITY = Number(process.env.QUALITY ?? 58);

const uri = (file, mime = 'image/webp') => `data:${mime};base64,${readFileSync(file).toString('base64')}`;

function clip(name) {
  const dir = path.join(tmp, name);
  mkdirSync(dir, { recursive: true });
  execFileSync('ffmpeg', [
    '-v', 'error', '-y', '-i', path.join(root, 'source/videos', `${name}.mp4`),
    '-vf', `select='not(mod(n,${STEP}))',scale=${WIDTH}:-2:flags=lanczos`, '-vsync', '0',
    '-c:v', 'libwebp', '-quality', String(QUALITY), path.join(dir, '%04d.webp'),
  ]);
  return readdirSync(dir).sort().map((f) => uri(path.join(dir, f)));
}

function still(name, width = 1800, quality = 74) {
  const out = path.join(tmp, `${name}.webp`);
  execFileSync('ffmpeg', [
    '-v', 'error', '-y', '-i', path.join(root, 'source/stills', `${name}.jpg`),
    '-vf', `scale='min(${width},iw)':-2:flags=lanczos`, '-c:v', 'libwebp', '-quality', String(quality), out,
  ]);
  return uri(out);
}

const manifest = {
  eye: clip('eye'),
  smoke: clip('smoke'),
  morph: clip('morph'),
  halo: still('halo'),
  tiger: still('tiger', 1376, 80),
  panther: still('panther'),
};

const result = await build({
  entryPoints: [path.join(root, 'src/main.tsx')],
  bundle: true,
  minify: true,
  write: false,
  format: 'iife',
  target: 'es2020',
  outdir: path.join(tmp, 'out'),
  define: { 'process.env.NODE_ENV': '"production"' },
  loader: { '.css': 'css' },
  absWorkingDir: root,
});
const js = result.outputFiles.find((f) => f.path.endsWith('.js')).text;
const css = result.outputFiles.find((f) => f.path.endsWith('.css')).text;

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
<meta name="theme-color" content="#07030a" />
<title>Karmin Pigment Study</title>
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Archivo:wdth,wght@62..125,300..800&family=Bodoni+Moda:ital,opsz,wght@0,6..96,400..800;1,6..96,400..800&display=swap" />
<style>${css}</style>
</head>
<body>
<div id="root"></div>
<script>window.__KARMIN_ASSETS__=${JSON.stringify(manifest)};</script>
<script>${js.replace(/<\/script/gi, '<\\/script')}</script>
</body>
</html>`;

const target = path.join(root, process.env.OUT ?? 'preview.html');
writeFileSync(target, html);
console.log(`preview.html  ${(html.length / 1048576).toFixed(1)} MB  (${manifest.eye.length} frames per clip)`);
