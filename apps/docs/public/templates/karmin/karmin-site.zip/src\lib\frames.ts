/**
 * Frame sequences without the memory bill.
 *
 * 120 decoded 1280x720 frames are ~440 MB of RAM, which phones will not
 * forgive. So we keep the small compressed files (a few MB per scene) as
 * Blobs and decode only a sliding window around the playhead into
 * ImageBitmaps. Everything outside the window is closed immediately.
 */

async function toBlob(url: string): Promise<Blob> {
  if (url.startsWith('data:')) {
    // Avoids fetch(), so embedded previews work even where fetch is restricted.
    const comma = url.indexOf(',');
    const mime = url.slice(5, url.indexOf(';'));
    const bin = atob(url.slice(comma + 1));
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new Blob([bytes], { type: mime });
  }
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed to load ${url}`);
  return res.blob();
}

export class FrameSet {
  readonly count: number;
  loaded = 0;
  ready = false;
  private blobs: (Blob | null)[];
  private bitmaps = new Map<number, ImageBitmap>();
  private pending = new Set<number>();
  private lo = 0;
  private hi = -1;
  private loading: Promise<void> | null = null;

  constructor(readonly urls: string[]) {
    this.count = urls.length;
    this.blobs = new Array(this.count).fill(null);
  }

  /** Download every frame (compressed). Safe to call more than once. */
  load(onProgress?: (fraction: number) => void, concurrency = 6): Promise<void> {
    if (this.loading) return this.loading;
    let next = 0;
    const worker = async () => {
      while (next < this.count) {
        const i = next++;
        try {
          this.blobs[i] = await toBlob(this.urls[i]);
        } catch {
          this.blobs[i] = null;
        }
        this.loaded++;
        onProgress?.(this.loaded / this.count);
      }
    };
    this.loading = Promise.all(Array.from({ length: concurrency }, worker)).then(() => {
      this.ready = true;
    });
    return this.loading;
  }

  /** Keep frames around `center` decoded, release the rest. */
  window(center: number, radius = 12) {
    const lo = Math.max(0, Math.floor(center - radius));
    const hi = Math.min(this.count - 1, Math.ceil(center + radius));
    this.lo = lo;
    this.hi = hi;
    for (let i = lo; i <= hi; i++) {
      const blob = this.blobs[i];
      if (!blob || this.bitmaps.has(i) || this.pending.has(i)) continue;
      this.pending.add(i);
      createImageBitmap(blob)
        .then((bm) => {
          this.pending.delete(i);
          if (i < this.lo - radius || i > this.hi + radius) bm.close();
          else this.bitmaps.set(i, bm);
        })
        .catch(() => this.pending.delete(i));
    }
    for (const [k, bm] of this.bitmaps) {
      if (k < lo - radius || k > hi + radius) {
        bm.close();
        this.bitmaps.delete(k);
      }
    }
  }

  /** Drop every decoded frame (scene is far away). */
  release() {
    if (!this.bitmaps.size) return;
    this.bitmaps.forEach((bm) => bm.close());
    this.bitmaps.clear();
  }

  /** Closest decoded frame to index `i`, or null when nothing is ready yet. */
  nearest(i: number): ImageBitmap | null {
    const base = Math.round(i);
    for (let d = 0; d < this.count; d++) {
      const a = this.bitmaps.get(base - d);
      if (a) return a;
      const b = this.bitmaps.get(base + d);
      if (b) return b;
      if (d > 40) break;
    }
    return null;
  }

  get(i: number): ImageBitmap | undefined {
    return this.bitmaps.get(i);
  }
}
