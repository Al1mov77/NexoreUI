import { useEffect, useRef, useState, type CSSProperties } from 'react';
import { assets } from '../assets';
import { finale, swatches } from '../content';
import { lerp, range, setVar, smooth, useSectionProgress, useTick } from '../lib/engine';
import { Lines } from './Type';

export function Finale() {
  const sec = useRef<HTMLElement>(null);
  const bg = useRef<HTMLImageElement>(null);
  const copy = useRef<HTMLDivElement>(null);
  const cta = useRef<HTMLAnchorElement>(null);
  const pointer = useRef({ x: 0, y: 0, tx: 0, ty: 0, active: false });
  const [pick, setPick] = useState(0);
  const accent = swatches[pick].hex;

  useSectionProgress(sec, ({ p, visible }) => {
    if (!visible) return;
    if (bg.current) bg.current.style.transform = `scale(${lerp(1.05, 1.28, smooth(p)).toFixed(4)})`;
    if (copy.current) {
      setVar(copy.current, '--in', smooth(range(p, 0.1, 0.4)));
      setVar(copy.current, '--out', 0);
    }
  });

  // Magnetic button: it leans towards the pointer while the pointer is close.
  useEffect(() => {
    const move = (e: PointerEvent) => {
      const el = cta.current;
      if (!el) return;
      const r = el.getBoundingClientRect();
      const cx = r.left + r.width / 2;
      const cy = r.top + r.height / 2;
      const d = Math.hypot(e.clientX - cx, e.clientY - cy);
      const near = d < Math.max(r.width, r.height) * 0.9;
      pointer.current.active = near;
      pointer.current.tx = near ? (e.clientX - cx) * 0.28 : 0;
      pointer.current.ty = near ? (e.clientY - cy) * 0.28 : 0;
    };
    window.addEventListener('pointermove', move);
    return () => window.removeEventListener('pointermove', move);
  }, []);

  useTick(() => {
    const q = pointer.current;
    q.x = lerp(q.x, q.tx, 0.14);
    q.y = lerp(q.y, q.ty, 0.14);
    if (cta.current) {
      cta.current.style.transform = `translate3d(${q.x.toFixed(2)}px, ${q.y.toFixed(2)}px, 0)`;
    }
  });

  return (
    <section
      ref={sec}
      id="index"
      className="finale"
      style={{ '--accent': accent } as CSSProperties}
    >
      <div className="finale__pin">
        <img ref={bg} className="finale__bg" src={assets.halo} alt="" decoding="async" />
        <div className="finale__wash" aria-hidden="true" />
        <div ref={copy} className="finale__copy beat">
          <p className="kicker fade">{finale.kicker}</p>
          <h2 className="display display--xl">
            <Lines lines={finale.lines} />
          </h2>
          <p className="body fade">{finale.body}</p>
          <ul className="swatches" role="radiogroup" aria-label="Pigment">
            {swatches.map((s, i) => (
              <li key={s.hex}>
                <button
                  type="button"
                  role="radio"
                  aria-checked={i === pick}
                  aria-label={`${s.name} ${s.hex}`}
                  className={i === pick ? 'is-on' : ''}
                  style={{ '--sw': s.hex } as CSSProperties}
                  onClick={() => setPick(i)}
                >
                  <i />
                  <span>{s.name}</span>
                  <code>{s.hex}</code>
                </button>
              </li>
            ))}
          </ul>
          <a ref={cta} className="cta" href="#overture" data-hover>
            <span>{finale.cta}</span>
            <svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true">
              <path d="M5 12h14M13 6l6 6-6 6" fill="none" stroke="currentColor" strokeWidth="1.6" />
            </svg>
          </a>
        </div>
        <p className="finale__foot">{finale.footnote}</p>
      </div>
    </section>
  );
}
