import { useEffect, useRef, type CSSProperties } from 'react';
import { assets } from '../assets';
import { plates } from '../content';
import { clamp, useSectionProgress } from '../lib/engine';
import { Lines } from './Type';

/** Horizontal gallery: vertical scroll drives the track, each crop drifts against it. */
export function Plates() {
  const sec = useRef<HTMLElement>(null);
  const track = useRef<HTMLDivElement>(null);
  const imgs = useRef<(HTMLImageElement | null)[]>([]);
  const cards = useRef<(HTMLElement | null)[]>([]);
  const travel = useRef(0);

  // The section is as tall as the track is wide, so one pixel of scroll is one pixel of travel.
  useEffect(() => {
    const fit = () => {
      const t = track.current;
      const s = sec.current;
      if (!t || !s) return;
      travel.current = Math.max(0, t.scrollWidth - window.innerWidth);
      s.style.height = `${travel.current + window.innerHeight}px`;
    };
    fit();
    const ro = new ResizeObserver(fit);
    if (track.current) ro.observe(track.current);
    window.addEventListener('resize', fit);
    window.addEventListener('load', fit);
    document.fonts?.ready.then(fit);
    return () => {
      ro.disconnect();
      window.removeEventListener('resize', fit);
      window.removeEventListener('load', fit);
    };
  }, []);

  useSectionProgress(sec, ({ p, visible }) => {
    if (!visible) return;
    const t = track.current;
    if (!t) return;
    t.style.transform = `translate3d(${(-clamp(p) * travel.current).toFixed(1)}px,0,0)`;
    const vw = window.innerWidth;
    // read every rect first, then write, to avoid layout thrash
    const rects = cards.current.map((c) => c?.getBoundingClientRect());
    imgs.current.forEach((im, i) => {
      const r = rects[i];
      if (!im || !r) return;
      const off = (r.left + r.width / 2 - vw / 2) / vw; // -1 .. 1 around centre
      im.style.setProperty('--shift', `${(off * -6).toFixed(2)}%`);
    });
  });

  return (
    <section ref={sec} id="plates" className="plates">
      <div className="plates__pin">
        <div ref={track} className="plates__track">
          <div className="plates__intro">
            <p className="kicker">{plates.kicker}</p>
            <h2 className="display">
              <Lines lines={plates.lines} mode="rise" />
            </h2>
            <p className="body">{plates.body}</p>
          </div>
          {plates.items.map((pl, i) => (
            <figure
              key={pl.n}
              className="plate"
              ref={(el) => {
                cards.current[i] = el;
              }}
              style={{ '--hex': pl.hex } as CSSProperties}
            >
              <div className="plate__frame">
                <img
                  ref={(el) => {
                    imgs.current[i] = el;
                  }}
                  src={assets[pl.still]}
                  alt={`Close crop: ${pl.title}`}
                  loading="lazy"
                  decoding="async"
                  style={
                    {
                      '--px': pl.x,
                      '--py': pl.y,
                      '--zoom': pl.zoom,
                      objectPosition: `${pl.x * 100}% ${pl.y * 100}%`,
                      transformOrigin: `${pl.x * 100}% ${pl.y * 100}%`,
                    } as CSSProperties
                  }
                />
              </div>
              <figcaption>
                <span className="plate__n">Plate {pl.n}</span>
                <span className="plate__t">{pl.title}</span>
                <span className="plate__chip">
                  <i />
                  <b>{pl.pigment}</b>
                  <code>{pl.hex}</code>
                </span>
              </figcaption>
            </figure>
          ))}
          <div className="plates__tail" aria-hidden="true" />
        </div>
      </div>
    </section>
  );
}
